﻿var MyApp = angular.module("MyApp", [])

MyApp.controller("BooksCtrl", ['$scope', '$http', function ($scope, $http) {
    $scope.books = [];
    $scope.data = {
        show: false
    };

    //show books
    $scope.getBooks = function(){
        console.log('will get books');
       return $http({
            method: 'GET',
            url: 'https://lital-book-store.herokuapp.com/books'
       }).then((response) => {
           $scope.books = response.data;
        }, (response) => {
            console.log(response)
        });
    }
    $scope.getBooks();

    //add new book
    $scope.saveBook = function (bookData) {
        console.log(bookData);
        console.log($scope.books);
        var myBook = { "name": bookData.bookname, "author": bookData.authorname, "date": bookData.publishdate, "stock": bookData.stock }
        //alert(bookData.bookname + bookData.authorname + bookData.publishdate + bookData.stock);
        $http.post("https://lital-book-store.herokuapp.com/newBook", myBook);

        $scope.data.show = false;
        $scope.getBooks();
        alert("please refresh the page to see your new book")
    }

    //show form
    $scope.showForm = function () {
        $scope.data.show = true;
    }

}]);